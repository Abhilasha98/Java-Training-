package com.sandip;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
public class Test 
{
public static void main(String[] args) 
{
Resource ctx=new ClassPathResource("applicationContext.xml");
BeanFactory fact=new XmlBeanFactory(ctx);

EmployeeDao dao=(EmployeeDao)fact.getBean("edao");
//dao.saveEmployee(new Employee(105,"affrena",45000.00f));
//System.out.println("Row Inserted");

//dao.updateEmployee(new Employee(105,"amrutha",50000.00f));
//System.out.println("Row updated");
//Employee e=new Employee();
//e.setId(105);
//dao.deleteEmployee(e);
//System.out.println("Row deleted");
}
}
