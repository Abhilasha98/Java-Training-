package com.sandip;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
public class Test 
{
public static void main(String[] args) throws ClassNotFoundException, SQLException 
{
	transaction();
}
private static void transaction() throws ClassNotFoundException, SQLException {
Resource ctx=new ClassPathResource("applicationContext.xml");
BeanFactory fact=new XmlBeanFactory(ctx);

StudentDao dao=(StudentDao)fact.getBean("edao");
System.out.println("***************************************");
System.out.println("enter 1 for TO CREATE STUDENT");
System.out.println("enter 2 for UPDATE STUDENT");
System.out.println("enter 3 for DELETE STUDENT");
System.out.println("enter 4 for SELECT ALL STUDENT");
System.out.println("enter 5 for SEARCH BY ROLLNUMBER");

System.out.println("***************************************");
Scanner ob = new Scanner(System.in);
System.out.println("ENTER YOUR CHOICE");
int option = ob.nextInt();
switch (option)
{
case 1:
dao.saveStudent(new Student(102,"sahana","bihar"));
System.out.println("Row Inserted");
transaction();
break;
case 2:
dao.updateStudent(new Student(101,"gagana","banglr"));
System.out.println("Row updated");
transaction();
break;
case 3:
Student e=new Student();
e.setRollno(103);
dao.deleteStudent(e);
System.out.println("Row deleted");
transaction();
break;
case 4:
List<Student> list=dao.getAllStudent();

for(Student e1:list)
System.out.println(e1);
transaction();
break;
case 5:
Student s1=new Student();
s1.setRollno(101);
Student list1=dao.searchByRollno(s1);
System.out.println(list1);
transaction();
break;


}
}
}