package com.sandip;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
public class StudentDao 
{
private JdbcTemplate jdbcTemplate;

public JdbcTemplate getJdbcTemplate() {
	return jdbcTemplate;
}

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}
public int saveStudent(Student e)
{
	String xyz="insert into Student values(' "+e.getRollno()+ " ',' "+e.getName()+" ',' "+e.getAddress()+" ')";
	return jdbcTemplate.update(xyz);	
}

public int updateStudent(Student e)
{
	String xyz="update Student set name=' "+e.getName() +" ' ,address=' "+e.getAddress() +" ' where rollno=' "+e.getRollno()+" ' ";
				return jdbcTemplate.update(xyz);	
}

public int deleteStudent(Student e)
{
	String xyz="delete from Student where rollno=' "+e.getRollno()+" ' ";
	return jdbcTemplate.update(xyz);	
}
public List<Student> getAllStudent()
{
return jdbcTemplate.query("select * from Student", new ResultSetExtractor<List<Student>>()
{
public List<Student> extractData(ResultSet rs)throws SQLException,DataAccessException
{
List<Student> list=new ArrayList<Student>();
while(rs.next())
{
Student e=new Student();
e.setRollno(rs.getInt(1));
e.setName(rs.getString(2));
e.setAddress(rs.getString(3));
list.add(e);
}
return list;
}
});
}
public Student searchByRollno(final Student s)
{
String xyz="select * from Student where rollno="+s.getRollno();



return jdbcTemplate.query(xyz, new ResultSetExtractor<Student>()
{
public Student extractData(ResultSet rs)throws SQLException,DataAccessException
{
Student list=new Student();
Student e=new Student();
if(rs.next())
{
e.setRollno(rs.getInt(1));
e.setName(rs.getString(2));
e.setAddress(rs.getString(3));
}
return e;
}
});
}
}
