package com.sandip;

import org.springframework.jdbc.core.JdbcTemplate;
public class EmployeeDao 
{
private JdbcTemplate jdbcTemplate;

public JdbcTemplate getJdbcTemplate() {
	return jdbcTemplate;
}

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}
public int saveEmployee(Employee e)
{
	String xyz="insert into employee2 values(' "+e.getId()+ " ',' "+e.getName()+" ',' "+e.getSalary()+" ',' "+e.getAge()+" ',' "+e.getDesignation()+" ')";
	return jdbcTemplate.update(xyz);	
}

public int updateEmployee(Employee e)
{
	String xyz="update employee2 set name=' "+e.getName()+" ',salary=' "+e.getSalary() +" ' ,age=' "+e.getAge() +" ' ,designation=' "+e.getDesignation() +" ' where id=' "+e.getId()+" ' ";
				return jdbcTemplate.update(xyz);	
}

public int deleteEmployee(Employee e)
{
	String xyz="delete from employee2 where id=' "+e.getId()+" ' ";
	return jdbcTemplate.update(xyz);	
}

}
