package com.sandip;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Test 
{
public static void main(String[] args) 
{
ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
EmployeeDao dao=(EmployeeDao)ctx.getBean("edao");
//int status=dao.saveEmployee(new Employee(103,"amrutha",60000.50f,"24","developer"));
//System.out.println(status);

//int status1=dao.updateEmployee(new Employee(101,"abhilasha",90000.50f,"34","Engineer"));
//System.out.println(status1);

//Employee e=new Employee();
//e.setId(102);
//int status=dao.deleteEmployee(e);
//System.out.println(status);

}
}
