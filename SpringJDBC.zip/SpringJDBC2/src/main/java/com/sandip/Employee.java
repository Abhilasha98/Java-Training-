//create table employee2(id number,name varchar2(30),salary number(8,2),age varchar2(30),designation varchar2(30));
package com.sandip;
public class Employee 
{
private int id;
private String name;
private float salary;
private String age;
private String designation;

public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(int id, String name, float salary, String age, String designation) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.age = age;
	this.designation = designation;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getSalary() {
	return salary;
}
public void setSalary(float salary) {
	this.salary = salary;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}



}
