package srbean;
public class Sub
{
private String name;
private String comment;

public void setSubject(String na)
{
this.name=na;
}
public String getComment()
{
if(name.equals("Java"))
return "java is a OOP language";
if(name.equals("Python"))
return "It is machine level language";
if(name.equals("C++"))
return "Object oriented language";
else
return "Sorry Invalied entry";
}
}