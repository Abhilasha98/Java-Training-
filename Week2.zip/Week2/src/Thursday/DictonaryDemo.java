package Thursday;

import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;

public class DictonaryDemo {
	public static void main(String[] args)
	{
	Dictionary<String, String> d=new Hashtable<String, String>();//Dictionary is It is abstract parent 
	d.put("1","sandip");
	d.put("2","shubham");
	d.put("3","sunil");
	d.put("4","ajay");
	for(Enumeration i=d.elements();i.hasMoreElements();)
	System.out.println("the value are :"+i.nextElement());
	}
}
