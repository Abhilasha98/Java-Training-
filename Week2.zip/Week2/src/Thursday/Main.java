package Thursday;

import java.util.EnumMap;
import java.util.Map;

enum purchase{Shop,Online};
public class Main {
	public static void main(String[] args) {

	EnumMap<purchase, Christsmas> em=new EnumMap<purchase, Christsmas>(purchase.class);
	Christsmas ob1=new Christsmas("Doll",500.0f);
	Christsmas ob2=new Christsmas("dress",2000.0f);
	em.put(purchase.Shop, ob1);
	em.put(purchase.Online,ob2);
		for(Map.Entry<purchase, Christsmas> ab:em.entrySet())
	{
		System.out.println(ab.getKey()+"    "+ab.getValue());
	}
	}}


