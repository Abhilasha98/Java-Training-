package Thursday;

import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;

public class DictionaryDemo1 {
	public static void main(String[] args)
	{
	AbstractMap<String, String> d=new HashMap<String, String>();//AbstractMap is the abstact parent class.
	d.put("1","sandip");
	d.put("2","shubham");
	d.put("3","sunil");
	d.put("4","ajay");
	for(Map.Entry ab:d.entrySet())
	{
		System.out.println(ab.getKey()+"    "+ab.getValue());
	}
	}
}
