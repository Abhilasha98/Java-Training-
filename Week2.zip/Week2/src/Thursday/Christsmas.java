package Thursday;

public class Christsmas {
String productname;
float price;
public Christsmas(String productname, float price) {
	super();
	this.productname = productname;
	this.price = price;
}
@Override
public String toString() {
	return "Christsmas [productname=" + productname + ", price=" + price + "]";
}




}
