package Thursday;

public class MeetingDetails {
	int empid,roomno;
	String name,Project,meetingstart,meetingend;
	public MeetingDetails(int empid, int roomno, String name, String project, String meetingstart, String meetingend) 
	{
		super();
		this.empid = empid;
		this.roomno = roomno;
		this.name = name;
		Project = project;
		this.meetingstart = meetingstart;
		this.meetingend = meetingend;
	}
	@Override
	public String toString() {
		return "MeetingDetails of Madhusudhan [empid=" + empid + ", roomno=" + roomno + ", name=" + name + ", Project=" + Project+ ", meetingstart=" + meetingstart + ", meetingend=" + meetingend + "]";
	}
}
