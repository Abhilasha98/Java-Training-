package Friday;

public class Thread1 extends Thread {
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println("Thread1"+" "+i);
			try {
				sleep(1000);//interrupts the flow of control 
			} catch (InterruptedException e) {
							e.printStackTrace();
			}
		}
	}
}
