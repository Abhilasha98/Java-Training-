package Friday;

public class Threads extends Thread {
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+" "+i);
			try {
				sleep(1000);
			} catch (InterruptedException e) {
							e.printStackTrace();
			}
		}

	}
	public static void main(String[] args) 
	{
		Threads ob1=new Threads();
		Threads ob2=new Threads();
		Threads ob3=new Threads();
		System.out.println(ob1.isAlive());
		ob1.start();
		System.out.println(ob1.isAlive());
		ob2.start();
		ob3.start();
	}

}
