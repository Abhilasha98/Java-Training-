package Wednesday;

import java.util.ArrayList;
import java.util.Arrays;
//to convert List to Array 
public class ListToArrayDemo {
	public static void main(String[] args)
	{
	ArrayList<String> list=new ArrayList<String>();
	list.add("apple");
	list.add("orange");
	list.add("grapes");
	list.add("strawberry");
	System.out.println("the list is :"+list);
	//to convert List to Array we use toArray()
	String arr[]=list.toArray(new String[list.size()]);
	System.out.println("Print the array :"+Arrays.toString(arr));
	}
}
