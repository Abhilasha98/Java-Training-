package Wednesday;

public class Emp {
int empno;
String name;
float salary;
public Emp(int empno, String name, float salary) {
	super();
	this.empno = empno;
	this.name = name;
	this.salary = salary;
}

}
