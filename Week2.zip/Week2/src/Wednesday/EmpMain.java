package Wednesday;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class EmpMain {
	public static void main(String[] args)
	{
	ArrayList<Emp> al=new ArrayList<Emp>();
	al.add(new Emp(101,"Shubham",60000));
	al.add(new Emp(102,"Trupti",20000));
	al.add(new Emp(103,"Ajay",1000));
	al.add(new Emp(104,"Kiran",90000));

	//Sorting by age
	Collections.sort(al,new Empsalary());
	Iterator<Emp> itr=al.iterator();
	while(itr.hasNext())
	{
		Emp emp=itr.next();
		System.out.println(emp.empno+"  "+emp.name+"  "+emp.salary);
	}
}
}