package Wednesday;

import java.util.Comparator;

public class Empsalary implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		Emp ob1=(Emp) o1;
		Emp ob2=(Emp) o2;
		if(ob1.salary==ob2.salary)		
		return 0;
		else if(ob1.salary > ob2.salary)
			return 1;
		else
			return -1;
	}

}
