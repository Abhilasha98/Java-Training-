package Wednesday;

public class Employee {
	int empno,age;
	String name;
	public Employee(int empno, int age, String name) {
		super();
		this.empno = empno;
		this.age = age;
		this.name = name;
	}

}
