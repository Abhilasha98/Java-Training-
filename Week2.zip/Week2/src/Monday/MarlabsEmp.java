package Monday;

public class MarlabsEmp implements Comparable<MarlabsEmp> {
	String name;
	MarlabsEmp(String name)
	{
		this.name=name;
	}
			@Override
			public int compareTo(MarlabsEmp obj)
		{
			return name.compareTo(obj.name);
}}
