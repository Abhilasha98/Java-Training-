package Monday;

public class UnBoxing {
	public static void main(String[] args) {
	Integer b=new Integer(10);//wrapper class to primative data type conversion
	int a=b;
	System.out.println(b);
}
}