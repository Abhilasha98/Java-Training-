package Monday;

import java.util.LinkedHashSet;


public class Emp{
	public static void main(String[] args)
	{
		Employee ob=new Employee(101,"sandip",20000);
		Employee ob1=new Employee(102,"shubam",2000);
		Employee ob2=new Employee(103,"trupti",20000);
		
	LinkedHashSet<Employee> ts=new LinkedHashSet<Employee>();
	ts.add(ob);
	ts.add(ob1);
	ts.add(ob2);
	System.out.println(ts);
	}
}