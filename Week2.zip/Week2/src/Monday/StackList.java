package Monday;

import java.util.Stack;

public class StackList {
	
		public static void main(String[] args)
		{
		Stack<Integer> st=new Stack<Integer>();
		st.push(10);//insert the data
		st.push(20);
		st.push(30);
		st.push(40);
		st.push(50);
		st.push(60);
		for(Object obj:st)
			System.out.println(obj);
		
		System.out.println("********************************");
		System.out.println(st.pop());//delete the data
		System.out.println(st.peek());//to see the last data
		System.out.println(st.pop());//delete the data
		System.out.println("********************************");
		for(Object obj:st)
			System.out.println(obj);
		System.out.println("********************************");
		//jdk1.8
		st.forEach((x)->System.out.println(x));//The wrapper class super class is Object//for each using lambda expressiom to print the data
		
		System.out.println(st.search(10));//It will return the position of 10.
		System.out.println(st.search(20));//position start from 1 it gives 60=1 and for index start from 0 it gives 10=0th index
		//System.out.print(st.indexOf(10));
		System.out.println(st.search(200));//element not found it displays -1
		try
		{
		System.out.println(st.pop());
		System.out.println(st.pop());
		System.out.println(st.pop());
		System.out.println(st.pop());
		System.out.println(st.pop());
		}
		catch(Exception ae)
		{
			System.out.println("Stack is empty");
		}
		}
}
