package Monday;

public class AutoBoxingDemo {
	public static void main(String[] args) {
		int a=10;//primative data type to wrapper class convertion is known as autoboxing
		Integer b=new Integer(a);
		System.out.println(b);
	}
}
