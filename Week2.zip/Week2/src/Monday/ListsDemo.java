package Monday;

import java.util.ArrayList;
import java.util.Collections;

public class ListsDemo {
	public static void main(String[] args) 
	{
	ArrayList<MarlabEmp> al=new ArrayList<MarlabEmp>();
	al.add(new MarlabEmp(104,"Geetanjali"));
	al.add(new MarlabEmp(103,"Shubam"));
	al.add(new MarlabEmp(102,"Deepak"));
	al.add(new MarlabEmp(101,"Trupti"));
	Collections.sort(al);
	for(MarlabEmp ob:al)
		System.out.println(ob.empid);
	}
}
