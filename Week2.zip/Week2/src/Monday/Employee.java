package Monday;

public class Employee {
int empno;
String name;
int salary;
public Employee(int empno, String name, int salary) {
	super();
	this.empno = empno;
	this.name = name;
	this.salary = salary;
}
@Override
public String toString() {
	return "Emp [empno=" + empno + ", name=" + name + ", salary=" + salary + "]";
}


}
