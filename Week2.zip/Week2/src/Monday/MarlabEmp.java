package Monday;

public class MarlabEmp implements Comparable<MarlabEmp> {
	Integer empid;
	String name;
	MarlabEmp(Integer empid,String name)
	{
		this.empid=empid;
		this.name=name;
	}
	@Override
			public int compareTo(MarlabEmp obj)
		{
			return empid.compareTo(obj.empid);
}
}