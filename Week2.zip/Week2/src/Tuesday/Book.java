package Tuesday;

public class Book {
String Bookid;
String name;
String price;
public Book(String bookid, String name, String price) {
	super();
	Bookid = bookid;
	this.name = name;
	this.price = price;
}
@Override
public String toString() {
	return "Book [Bookid=" + Bookid + ", name=" + name + ", price=" + price + "]";
}

}
