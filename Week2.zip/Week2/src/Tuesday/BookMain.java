package Tuesday;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BookMain {
	public static void main(String[] args) 
	{
		HashMap<String,Book> map=new HashMap<String,Book> ();
		Book bk1=new Book("1","maths","5600.50f");
		Book bk2=new Book("2","science","5700.50f");
		Book bk3=new Book("3","social","5800.50f");
		map.put("1", bk1);
		map.put("2", bk2);
		map.put("3", bk3);
		Scanner ob=new Scanner(System.in);
		
		
		System.out.println("enter the bookno you want ");
		String sc= ob.nextLine();
		map.remove(sc);
		System.out.println("Book is removed having the number\n" +sc);
		
		System.out.println("********************");
		
		System.out.println("enter the book id, name and price of the book to increses");
		String bookid=ob.nextLine();
		String name=ob.nextLine();
		String price=ob.nextLine();
		Book b= new Book(bookid , name,price);
		map.replace(bookid, b);
	
		System.out.println("********************");
		System.out.println("the total book available is");
		
		for(Map.Entry<String, Book> m: map.entrySet())
			System.out.println(m.getKey()+ "    "+m.getValue());
		
		System.out.println("********************");
		
		System.out.println("Enter the bookno you want to search");
		String bookno=ob.nextLine();
		
		for(Map.Entry<String, Book> m: map.entrySet())
			if(m.getKey().equals(bookno))
			System.out.println(m.getKey()+ "    "+m.getValue());
			
		
		
}
}