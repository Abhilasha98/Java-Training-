package Tuesday;

import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQueueDemo {
public static void main(String[] args) {
	PriorityQueue<String> queue=new PriorityQueue<String>();
	queue.add("Abhilasha");//first-in-first-out
	queue.add("affrena");
	queue.add("amrutha");
	queue.add("kajal");
	System.out.println(queue.element());//this will display the head element
	System.out.println(queue.peek());//this will display the head element
	System.out.println(queue.remove());//this removes the head element
	System.out.println(queue.poll());//remove the head element
	System.out.println("*****************");
	Iterator itr = queue.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
		queue.add("sunil");
		queue.add("trupti");
		System.out.println("************************************************");
		Iterator itr1=queue.iterator();
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		}
		System.out.println("the head is "+queue.element());//this will display the head element
	}

	
}

