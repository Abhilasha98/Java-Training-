package com.enu;

public enum Colors {

	RED, GREEN, BLUE
}
