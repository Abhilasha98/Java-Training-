package Thursday;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Student1 {
	public static void main(String[] args)throws Exception
	{
		Scanner ob=new Scanner(System.in);
		System.out.println("enter empno,name,address,DOJ");
		int empno=ob.nextInt();
		String name=ob.next();
		String address=ob.next();
		String DOJ=ob.next();
		  
	     
		System.out.println(
				"please enter ur choice:\n" + "1 for display\n" + "2 for insert\n" + "3 for update\n" + "4 for delete");



				int choice = ob.nextInt();
				switch (choice) {	    	 case 1:  
	    		 Class.forName("com.mysql.cj.jdbc.Driver");
	    			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/abhilasha", "root", "abhi");
			
	    			Statement st=con.createStatement();
	    			ResultSet rs = st.executeQuery("select * from marlabemp ");
	    			while (rs.next()) {
	    			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4));
	    			}
			break;
	    	 case 2:
	    		 Class.forName("com.mysql.cj.jdbc.Driver");
	    			Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/abhilasha", "root", "abhi");
			PreparedStatement st1=con1.prepareStatement("insert into marlabemp values(?,?,?,?)");
			st1.setInt(1, empno);
			st1.setString(2,name);
			st1.setString(3,address);
			st1.setString(4,DOJ);
			st1.execute();
			System.out.println("row inserted");
			break;
	    	 case 3:
	    		 Class.forName("com.mysql.cj.jdbc.Driver");
	    			Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/abhilasha", "root", "abhi");
	    		 PreparedStatement st2=con2.prepareStatement("update  marlabemp set name=?,address=?,DOJ=? where empno=?");
	    			st2.setInt(1, empno);
	    			st2.setString(2,name);
	    			st2.setString(3,address);
	    			st2.setString(4,DOJ);
	    			st2.execute();
	    			System.out.println("row updated");
	    			break;
	    	 case 4:
	    		 Class.forName("com.mysql.cj.jdbc.Driver");
	    			Connection con3 = DriverManager.getConnection("jdbc:mysql://localhost:3306/abhilasha", "root", "abhi");
	    		 PreparedStatement st3=con3.prepareStatement("delete from marlabemp  where empno=?");
	    			st3.setInt(1,empno);
	    			st3.execute();
	    			System.out.println("row deleted");
	    			break;
			
	    	 
	    }
	}
}
