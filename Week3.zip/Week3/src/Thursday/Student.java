package Thursday;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Student 
{
public static void main(String[] args)throws Exception
{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		Scanner ob=new Scanner(System.in);
		System.out.println("enter  empno which you want to delete");
		
		int empno=ob.nextInt();
		PreparedStatement st=con.prepareStatement("delete marlabsstud  where empno=?");
		st.setInt(1,empno);
		st.execute();
		System.out.println("row deleted");
}
}