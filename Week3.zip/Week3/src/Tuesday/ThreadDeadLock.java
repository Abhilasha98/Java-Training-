package Tuesday;

public class ThreadDeadLock {
	public static void main(String[] args)throws Exception
	{
	Object ob1=new Object();
	Object ob2=new Object();
	Object ob3=new Object();

	Thread t1=new Thread(new SeeThread(ob1,ob2),"t1");
	Thread t2=new Thread(new SeeThread(ob2,ob3),"t2");
	Thread t3=new Thread(new SeeThread(ob3,ob1),"t3");
	t1.start();
	Thread.sleep(5000);
	t2.start();
	Thread.sleep(5000);
	t3.start();
	Thread.sleep(5000);
	}
}
