package Tuesday;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Tasks implements Runnable {
	String taskName;

	public Tasks(String taskName) 
	{
			this.taskName = taskName;
	}

	@Override
	public void run()
	{
	try
	{
		for (int j=0;j<5;j++)
		{
			if(j==0)
			{
				Date dt=new Date();
				SimpleDateFormat sdf=new SimpleDateFormat("hh : mm : ss");
				System.out.println("The start time of :"+  taskName +"  "+sdf.format(dt));
			}
			else
			{
				Date dt=new Date();
				SimpleDateFormat sdf=new SimpleDateFormat("hh : mm : ss");
				System.out.println("The execution time of :"+  taskName +"  "+sdf.format(dt));
							}
	Thread.sleep(1000);
		}
		System.out.println(taskName +" is Completed");
	}
		catch(Exception ae)
	{
			ae.printStackTrace();
	}	}}
