package Friday;
import java.sql.*;
import java.util.*;
public class Student 
{
public static void main(String[] args)throws Exception
{
	Scanner ob=new Scanner(System.in);
	System.out.println("enter studID,name,address");
	int studid=ob.nextInt();
	String name=ob.next();
	String address=ob.next();
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/abhilasha", "root", "abhi");
		PreparedStatement st=con.prepareStatement("insert into student values(?,?,?)");
		st.setInt(1, studid);
		st.setString(2,name);
		st.setString(3,address);
		st.execute();
		System.out.println("row inserted");
		
		}
}