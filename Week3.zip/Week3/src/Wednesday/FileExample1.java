package Wednesday;

import java.io.File;
import java.util.Scanner;

public class FileExample1 {
public static void main(String[] args) {
	Scanner ob=new Scanner(System.in);
	System.out.println("Enter the file name");	
	String fname=ob.next();
	File f=new File(fname);
	System.out.println("the file name is "+f.getName());
	System.out.println("the file path is "+f.getPath());
	System.out.println("the file obsolute path is "+f.getAbsolutePath());
	System.out.println("the file is existing "+f.exists());
	System.out.println("the file is in read mode "+f.canRead());
	System.out.println("the file is in write mode "+f.canWrite());
	System.out.println("the file is in execute mode "+f.canExecute());
	System.out.println("the file length is "+f.length());
	System.out.println("this is a file  "+f.isFile());
	System.out.println("this is a directory "+f.isDirectory());
	}

}
