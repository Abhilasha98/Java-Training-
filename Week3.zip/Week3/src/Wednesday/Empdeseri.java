package Wednesday;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Empdeseri {
	public static void main(String[] args) throws Exception
	{
		Employee e1=null;
		FileInputStream fos=new FileInputStream("object1.txt");
		ObjectInputStream os=new ObjectInputStream(fos);
		e1=(Employee) os.readObject();
		fos.close();os.close();
	System.out.println("the rollno is :"+e1.empno);
	System.out.println("the name is :"+e1.name);
	System.out.println("the address is :"+e1.designation);
	System.out.println("the address is :"+e1.salary);
}}
