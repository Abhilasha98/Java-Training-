package Wednesday;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileExample5 {
public static void main(String[] args) throws IOException {
	FileReader fr=new FileReader("student.txt");
	BufferedReader br=new BufferedReader(fr);
	String x;
	while((x=br.readLine())!=null) //null indicates EOF 
	{
		System.out.println(x);
	}
	}
}

