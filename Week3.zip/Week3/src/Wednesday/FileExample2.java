package Wednesday;

import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileExample2 {
	public static void main(String[] args) throws IOException
	{
	DataInputStream dis=new DataInputStream(System.in);
	FileOutputStream fos=new FileOutputStream("student.txt");//file not found means it will automatically create a file
	System.out.println("enter the data");
	int data;
	while((data=dis.read())!='\n')  //data is internally converted into byte format and while writing it will again convert into 				//character
	{
		fos.write(data);
	}
	System.out.println("file writing over");
	dis.close(); //pointer will be released.
	fos.close();
	}
}
