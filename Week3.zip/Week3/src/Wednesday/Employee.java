package Wednesday;

import java.io.Serializable;

public class Employee implements Serializable {
	transient int empno;
	 String name,designation;
	 int salary;
}
