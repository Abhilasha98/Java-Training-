package Monday;

public class ThreadPoolDemo implements Runnable {

String msg;
	ThreadPoolDemo(String x)
	{
		this.msg=x;
	}
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+" Start Thread ="+msg);
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
				e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName()+" End Thread ");
		
		}

}
