package Monday;

public class GarbageDemo {

public void finalize()
{
	System.out.println("the object is going to garbage collection");
}
public static void main(String[] args) {
	GarbageDemo ob1=new GarbageDemo();
	GarbageDemo ob2=new GarbageDemo();
	
	ob1=null;
	ob2=null;
	System.gc();//It will cal the finalized method make object to garbage collected.
}
}
