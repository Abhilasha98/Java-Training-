package com.mark;

public interface Marker {

}
