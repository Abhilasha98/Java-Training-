package com.mark;

public class Main {

	public static void main(String[] args) {
		Ab a = new Ab();
		 if (a instanceof Ab) {
	          
	        }

	}

}
