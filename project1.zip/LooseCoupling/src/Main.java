
public class Main {

	public static void main(String[] args) {
		
Animal ref = new Cat();
ref.eat();
	}

}
