package Tightcoupling;

public class Main {

	public static void main(String[] args) {
		Dog d = new Dog();
		d.eat();

	}

}
