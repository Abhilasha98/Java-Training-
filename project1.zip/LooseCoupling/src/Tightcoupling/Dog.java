package Tightcoupling;

public class Dog extends Cat {

		

}
