package Tightcoupling;

public class Cat {

	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("milk");
	}

}
