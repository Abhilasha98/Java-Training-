
public interface Animal {
void eat();
}
