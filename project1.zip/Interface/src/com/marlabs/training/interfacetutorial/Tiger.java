package com.marlabs.training.interfacetutorial;

public class Tiger implements Animal {
	

	@Override
	public void run() {
		System.out.println("fastly");
		
	}
	
}
