package com.marlabs.training.interfacetutorialanimal;

import com.marlabs.training.interfacetutorial.Animal;
import com.marlabs.training.interfacetutorial.Tiger;

public class Main {
	public static void main(String[] args) {
		Animal.weight();
		Tiger tiger = new Tiger();
		tiger.foodHabits();
		tiger.run();

	}

}
