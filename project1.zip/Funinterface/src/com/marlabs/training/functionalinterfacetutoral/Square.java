package com.marlabs.training.functionalinterfacetutoral;

@FunctionalInterface
public interface Square {
	
	    int calculate(int x);
	}
	  
	