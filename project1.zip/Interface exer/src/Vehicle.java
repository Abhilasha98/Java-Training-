
public interface Vehicle {
 abstract String brand();
 abstract String speedUp();
 abstract String slowDown();
  
 default String turnAlarmOn() {
	 return "2AM";
	 
 }
 default String turnAlarmOff() {
	 return "Off";
 }
	 static String colour() {
		 return "blue";
	 
 }
 
}
