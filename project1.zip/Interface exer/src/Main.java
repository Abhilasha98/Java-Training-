
public class Main {

public static void main(String[] args) {
Vehicle ref = new Car("bmw");
System.out.println(Vehicle.colour());
System.out.println(ref.slowDown());
System.out.println (ref.speedUp());
System.out.println  (ref.turnAlarmOff());
System.out.println  (ref.turnAlarmOn());


	}

}
