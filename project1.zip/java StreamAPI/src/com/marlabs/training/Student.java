package com.marlabs.training;

public class Student {
	int id;
	String name;
	int marks;



	public Student(int id, String name, int marks) {
	super();
	this.id = id;
	this.name = name;
	this.marks = marks;
	}
}
