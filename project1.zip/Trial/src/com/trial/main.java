package com.trial;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class main {

	public static void main(String[] args) {
Map<Integer, String> hmap = new HashMap<Integer,String>();
hmap.put(1, "monkey");
hmap.put(2,"rose");
hmap.put(3, "tiger");
hmap.put(4, "red");
hmap.forEach((key,value)->System.out.println(key + "-" + value));
hmap.forEach((key,value)->{

if (key==4) {
	System.out.println("value for key 4is " +value);
}
	

});
hmap.forEach((key,value)->{

if (value=="red") {
	System.out.println("key for value red is " +key);
}
	

});}}
