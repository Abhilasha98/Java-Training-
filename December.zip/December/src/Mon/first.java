package Mon;

import java.util.*;
	 class first
	{
	int rollno;//intance variable
	String name,address;
	first()
	{
		System.out.println("this is a default constructor which is without any parameter");
	}
	first(int rollno,String name,String address)//local variable
	{
		this.rollno=rollno;//to differenciate between intance variable and local variable we use this
		this.name=name;//keyword.
		this.address=address;
	}
	void display()
	{
		System.out.println("the rollno is "+rollno);
		System.out.println("the name is "+name);
		System.out.println("the address is "+address);
		}
	int sum(int a,int b) //method overloading
	{
		return a+b;
	}
	float sum(float a,float b)
	{
		return a+b;
	}
	}
	
	
	













