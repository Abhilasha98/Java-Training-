package Mon;

public class second
{
public static void main(String[] args) {
	first ob=new first();
	first ob1=new first(101,"ajay","bangalore");
	first ob2=new first(102,"trupti","orissa");
	ob1.display();ob2.display();
	System.out.println(ob1.sum(6, 6));//compiler will decide where to send the value
	System.out.println(ob1.sum(6.5f, 6.3f));
	
}
}