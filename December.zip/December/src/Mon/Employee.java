package Mon;

public class Employee {
	 int empno;
	 String name;
 String designation;
 int salary;
	Employee(int empno,String name,String designation,int salary)//local variable
	{
		this.empno=empno;//to differenciate between intance variable and local variable we use this
		this.name=name;//keyword.
		this.designation=designation;
		this.salary=salary;
	}
	void display()
	{
		System.out.println("the empno is "+empno);
		System.out.println("the name is "+name);
		System.out.println("the designation  is "+designation);
		System.out.println("the salary  is "+salary);
	
		}
	
	
}
