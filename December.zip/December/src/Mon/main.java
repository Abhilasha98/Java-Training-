package Mon;

public class main {

	public static void main(String[] args) {
		Employee ob=new Employee(1,"abhi","developer",12800);
		Employee ob1=new Employee(2,"ajay","testing",12000);
		
		ob.display();ob1.display();
	}

}
