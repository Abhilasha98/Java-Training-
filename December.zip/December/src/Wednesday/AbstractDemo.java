package Wednesday;
abstract class Abstract1
{
	Abstract1(){
		System.out.println("this is a constructor");
	}
	Abstract1(int a,int b)
	{
		System.out.println("the sum of super constrctor is "+(a+b));
	}
		
	
abstract void display();
int sum(int a,int b)
{
	return a+b;
}

}
class AbstractDemo extends Abstract1
{
	AbstractDemo()
	{
		super();
	}
	AbstractDemo(int a,int b)
	{
		super(a,b);
	}
	@Override
	void display() 
	{
		System.out.println("This is display");
		}
	public static void main(String[] args) {
		AbstractDemo ob=new AbstractDemo(7,8);
		AbstractDemo ob1=new AbstractDemo();
		System.out.println("the sum is "+ob1.sum(6, 3));
		ob.display();
	}
}