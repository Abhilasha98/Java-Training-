package Wednesday;

public interface Employee {
	int empno=101;
	String emp_name="abhilasha",address="Bangalore";
	void display1();

	} 
interface Department{
int deptno=1;
String name="Associate",loc="north bangalore";
void display2();
}

