package Wednesday;
interface Interface1
{
	 int a=10;//this is by default static(we can access it without object and final(cann't be changed)
void display1();
}
interface Interface2 extends Interface1
{
void display2();
}
interface Interface3
{
void display3();
}
interface Interface4 
{
void display4();
}
 