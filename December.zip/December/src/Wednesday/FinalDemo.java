package Wednesday;

public class FinalDemo {
	
		final int a=10;
		final void display()
		{
			System.out.println("this is final display");
		}
		public static void main(String[] args) {
			FinalDemo ob=new FinalDemo();
			ob.display();
			System.out.println("the value of a is"+ob.a);
		}
}
