package Wednesday;

abstract public class Bank {
	abstract void register(); 
	abstract void loan();
	abstract void creditcard();
	abstract void debitcard();
	
	}

