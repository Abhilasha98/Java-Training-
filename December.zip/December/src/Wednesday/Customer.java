package Wednesday;

public class Customer extends Bank {

	@Override
	void register() {
		System.out.println("welcome to bank");
	}

	@Override
	void loan() {
		System.out.println("apply for loan");
		
	}

	@Override
	void creditcard() {
		// TODO Auto-generated method stub
		System.out.println("apply for credit card");
	}

	@Override
	void debitcard() {
		// TODO Auto-generated method stub
		System.out.println("apply for debit card");
	}
	public static void main(String[] args) {
		Customer c = new Customer();
		c.register();
		c.loan();
		c.creditcard();
		c.debitcard();
		}
}

