package Wednesday;

 public class InterfaceDem implements Interface2,Interface3,Interface4
{
	@Override
	public void display1() {
				System.out.println("display1");	 }
	@Override
	public void display4() {
		System.out.println("display4");		}
	@Override
	public void display3() {
		System.out.println("display3");			}
	@Override
	public void display2() {
		System.out.println("display2");
			}
	 public static void main(String[] args) {
		 int a=10;
		System.out.println("the value of a is "+a);
		InterfaceDem ob=new InterfaceDem();
	ob.display1(); ob.display2(); ob.display3();  ob.display4();
	}
}