package Friday;

import java.util.LinkedHashSet;

public class SetClass {
	
		public static void main(String[] args)
		{
			Student ob=new Student(101,"sandip","bangalore");
			Student ob1=new Student(102,"shubam","bangalore");
			Student ob2=new Student(103,"trupti","bangalore");
			
		LinkedHashSet ts=new LinkedHashSet();
		ts.add(ob);
		ts.add(ob1);
		ts.add(ob2);
		System.out.println(ts);
		}
}
