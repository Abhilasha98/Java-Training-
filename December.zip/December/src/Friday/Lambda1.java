package Friday;
@FunctionalInterface
interface example1
{
	public void display();  //only one abstract method
}
public class Lambda1
{
public static void main(String[] args) 
{
int length=10;
int breadth=20;
example1 obj=()->//here we create the object for interface and define the method() 
{
	System.out.println("the length is "+length);
	System.out.println("the breadth is "+breadth);
	System.out.println("the area is "+(length*breadth));
};
obj.display();
}
}
//()->  Method define