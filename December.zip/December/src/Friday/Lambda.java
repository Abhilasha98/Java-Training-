package Friday;

@FunctionalInterface
interface example5
{
	public void display(); //only one method
}
@FunctionalInterface
interface example2
{
	public String name();
}

@FunctionalInterface
interface example3
{
	public String address(String loc);
}
@FunctionalInterface
interface example4
{
	public int sum(int a,int b);
}

public class Lambda
{
public static void main(String[] args) 
{
int length=10;
int breadth=20;
example5 obj=()->     //display method defined
{
	System.out.println("the length is "+length);
	System.out.println("the breadth is "+breadth);
	System.out.println("the area is "+(length*breadth));
};
obj.display();

example2 obj1=()->
{
	return "Lambda Expression";
};
System.out.println(obj1.name());

example3 obj2=(loc)->
{
	return "My Loaction is :"+loc;
};
System.out.println(obj2.address("Udupi"));

example4 obj3=(a,b)->(a+b);
System.out.println("the sum is "+obj3.sum(400,500));
}
}
