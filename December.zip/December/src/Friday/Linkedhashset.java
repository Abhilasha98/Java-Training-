package Friday;

import java.util.LinkedHashSet;

public class Linkedhashset {
	
		public static void main(String[] args)
		{
		LinkedHashSet<Integer> ts=new LinkedHashSet<Integer>();
		ts.add(70);
		ts.add(20);
		ts.add(30);
		ts.add(10);
		ts.add(50);
		ts.add(50);
		ts.add(60);
		System.out.println(ts);
		}
}
