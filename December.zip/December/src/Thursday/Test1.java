package Thursday;

public class Test1 {
	public static void main(String h[]) 
	{
	String a=h[0];
	String b=h[1];
	String c=h[2];
	int x=Integer.parseInt(a);
	int y=Integer.parseInt(b);
	int z=Integer.parseInt(c);
	int sum=x+y+z;
	System.out.println("the sum is "+sum);
	}
}
