package Thursday;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionClass {
	public static void main(String[] args) 
	{
		try
		{
	Scanner ob=new Scanner(System.in);
	System.out.println("Enter 2 nos");
	int a=ob.nextInt();
	int b=ob.nextInt();
	int c=a/b;
	System.out.println("The result is "+c);
		}
		catch(ArithmeticException ae)
		{
			System.out.println("the error is "+ae);
		}
		catch(InputMismatchException ae)
		{
			System.out.println("the errorr is "+ae);
		}
		catch(Exception ae) //this can handle all types of error
		{
			System.out.println("the errorrr is "+ae);
		}
	System.out.println("The end of the program");
	}
}
