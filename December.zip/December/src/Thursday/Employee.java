package Thursday;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Employee {
	public static void main (String[] args)throws Exception
    {
    	Scanner ob=new Scanner(System.in);
          try
    {
      System.out.println("enter empno :");
        String str =ob.next();
        int num = Integer.parseInt(str);
            }
    catch(NumberFormatException ex)
    {
           System.out.println("Enter only number");
              }
         finally
    {
        System.out.println("Enter name,age and qualification");
        String name=ob.next();
        int age=ob.nextInt();
        String qual=ob.next();
        if(age>=20 && qual.equalsIgnoreCase("btech"))
        	System.out.println("you are eligible");
        else
        	throw new Exception("not eligible");
    }
    }
}
