package Monday;

public class First {
	public static void main(String[] args) {
		System.out.println("Welcome to jdl 1.8");
		byte a=10;
		short b =20;
		int c = 30;
		long d = 40;
		float e = 5.6f;
		double f = 6.7;
		String g = "abhi";
		char h = 'a';
		System.out.println(a+" "+b+" "+c);
		System.out.println(d+" "+e+" "+f);
		System.out.println(g+" "+h);
	}

}
