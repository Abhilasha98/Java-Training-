package Monday;

public class Test {
	
	
	public static void main(String[] args) {
		Employe ob=new Employe();
		ob.setEmpno(101);
		ob.setName("Trupti");
		ob.setDesignation("software eng");
		ob.setSalary(45000.50f);
		System.out.println(ob.getEmpno());
		System.out.println(ob.getName());
		System.out.println(ob.getSalary());
		System.out.println(ob.getDesignation());
	}
	
}
