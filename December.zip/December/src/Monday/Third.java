package Monday;
import java.lang.*;
import java.util.*;
public class Third
{
int rollno;
String name;
float phy;
float chem;
float maths,total;

void input()
{
	Scanner ob=new Scanner(System.in);
	System.out.println("enter rollno,name,physics and chemisry  and maths marks of student");
	rollno=ob.nextInt();
	name=ob.next();
	 phy=ob.nextFloat();
	chem=ob.nextFloat();
	maths = ob.nextFloat();
	total = phy + chem + maths;
	
}
void display()
{
System.out.println("the student rollnumer is "+rollno);	
System.out.println("the studnet  name  is "+name);	

System.out.println("the student physics and chemistry  and maths marks is " +phy+" " +chem+ " " +maths);	
System.out.println("The student total marks is:" + total);


}
public static void main(String[] args) {
	Third obj=new Third();
	obj.input();
	obj.display();
}
}
