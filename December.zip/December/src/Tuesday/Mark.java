package Tuesday;

public class Mark  extends StudentConstructor{
	int phy,chem,math,total,avg;
	String grade;
	Mark(int rollno,String name,String address,int phy,int chem,int math)
	{
		super(rollno,name,address);
		this.phy=phy;
		this.chem=chem;
		this.math=math;
		total=phy+chem+math;
		avg=total/3;
		if(avg>=70)
			grade="First Grade";
		else if(avg>=60)
			grade="Second Grade";
		else if(avg>=50)
			grade="Third Grade";
		else
			grade="Fail";
	}
	void display()
	{
		super.display();
		System.out.println("the total is "+total);
		System.out.println("the average is "+avg);
		System.out.println("The grade is "+grade);
	}
	public static void main(String[] args)
	{
		Mark ob=new Mark(101,"sandip","Bangalore",77,88,66);
		ob.display();
	}
}
