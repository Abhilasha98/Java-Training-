package Tuesday;

import java.util.Scanner;

public class Marks extends Stu {
	
		int phy,chem,math,total,avg;
		String grade;
		void input()
		{
			super.input();
			Scanner ob=new Scanner(System.in);
			System.out.println("enter phy,chem,math marks");
			phy=ob.nextInt();
			chem=ob.nextInt();
			math=ob.nextInt();
			total=phy+chem+math;
			avg=total/3;
			if(avg>70)
				grade="First Grade";
			else if(avg>60)
				grade="Second Grade";
			else if(avg>50)
				grade="Third Grade";
			else
				grade="Fail";
		}
		void display()
		{
			super.display();
			System.out.println("the total is "+total);
			System.out.println("the average is "+avg);
			System.out.println("The grade is "+grade);
		}
		public static void main(String[] args)
		{
			Marks ob=new Marks();
			ob.input();
			ob.display();
		}
}
