package Tuesday;

import java.util.Scanner;

public class Bank {
	String accno,name,email,Balance;
	void input()
	{
		Scanner ob=new Scanner(System.in);
		System.out.println("Enter accno,name,email,balance of the customer");
		accno=ob.nextLine();//it excepts space in between
		name=ob.nextLine();
		email=ob.nextLine();
		Balance=ob.nextLine();
	}
	void display()
	{
		System.out.println("the accno is "+accno);
		System.out.println("the name is "+name);
		System.out.println("the email is "+email);
		System.out.println("the balance is "+Balance);
	}
	public static void main(String[] args) {
		Bank[] obj=new Bank[20];
		for(int i=0;i<20;i++)
		{
			System.out.println("enter data of customer no"+(i+1));
			obj[i]=new Bank();
			obj[i].input();
		}
		for(int i=0;i<20;i++)
		{
			System.out.println("data of customer no"+(i+1));
			obj[i].display();
		}

	}
}
