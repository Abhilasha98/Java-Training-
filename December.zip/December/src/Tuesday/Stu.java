package Tuesday;

import java.util.Scanner;

public class Stu {
	
		int rollno;
		String name,address;
		void input()
		{
			Scanner ob=new Scanner(System.in);
			System.out.println("enter rollno,name,address");
			rollno=ob.nextInt();
			name=ob.next();
			address=ob.next();
		}
		void display()
		{
			System.out.println("the rollno is"+rollno+"the name is "+name+"the address is "+address);
		}
}
