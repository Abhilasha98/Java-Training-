package Tuesday;

public class Array {

}
