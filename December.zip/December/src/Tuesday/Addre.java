package Tuesday;

public class Addre extends Mar{
	String loc;
	Addre(int rollno, String name, String address, int phy, int chem, int math,String loc) 
	{
		super(rollno, name, address, phy, chem, math);
	this.loc=loc;
	}
void display()
{
	super.display();
	System.out.println("the location is "+loc);
}
public static void main(String[] args) {
	Addre ob=new Addre(1001,"sandip","Bangalore",77,77,55,"north bangalore");
	ob.display();
}
}
