package com.javatpoint.beans;

public class Emp {
private String id;
private String name;
private String salary;
private String designation;
private String age;
private String cname;

public Emp() {}



public Emp(String id, String name, String salary, String designation, String age, String cname) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.designation = designation;
	this.age = age;
	this.cname = cname;
}



public String getId() {
	return id;
}



public void setId(String id) {
	this.id = id;
}



public String getName() {
	return name;
}



public void setName(String name) {
	this.name = name;
}



public String getSalary() {
	return salary;
}



public void setSalary(String salary) {
	this.salary = salary;
}



public String getDesignation() {
	return designation;
}



public void setDesignation(String designation) {
	this.designation = designation;
}



public String getAge() {
	return age;
}



public void setAge(String age) {
	this.age = age;
}



public String getCname() {
	return cname;
}



public void setCname(String cname) {
	this.cname = cname;
}




}
