package com.trial;

public interface Lambda {
String stringConcat(String str1, String str2);
}
