
public class Car implements Vehicle {
	private String brand;

	public Car(String brand) {
		super();
		this.brand = brand;
	}

	@Override
	public String brand() {
		// TODO Auto-generated method stub
		return brand;
	}

	@Override
	public String speedUp() {
		// TODO Auto-generated method stub
		return "speed";
	}

	@Override
	public String slowDown() {
		// TODO Auto-generated method stub
		return "slow";
	}
}