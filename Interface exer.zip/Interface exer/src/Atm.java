import java.util.Scanner;

public class Atm {

	public static void main(String[] args) {
		int balance, withdraw, deposit;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the balance");
		balance = sc.nextInt();
		while (true) {
			System.out.println("Enter 1 for amount withdraw");
			System.out.println("Enter 2 for amount deposit");
			System.out.println("Enter 3 for amount balance");
			System.out.println("Enter 4 for exit");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter the amount to withdraw");
				withdraw = sc.nextInt();
				if (balance >= withdraw) {
					balance = balance - withdraw;
					System.out.println(+withdraw + "amount");
					break;
				}
			case 2:
				System.out.println("Enter the amount to deposit");
				deposit = sc.nextInt();
				balance = balance + deposit;
				System.out.println(+deposit + "amount");
				break;

			case 3:
				System.out.println(+balance + "availabel");
				break;

			case 4:
				System.exit(0);
				break;

			}
		}
	}
}
