package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login extends HttpServlet {
 @Override
protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("Welcome to servlet");
	//Reading Data
	String email= req.getParameter("Email");
	String password= req.getParameter("pword");
	System.out.println("Email:"+email+" & Password:"+password);
	//Printing in Browser
	PrintWriter out= resp.getWriter();
	out.println("Welcome to Web Development");
	out.println("Email: "+email);
	out.println("Password: "+password);
}
}
