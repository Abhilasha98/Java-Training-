package com.dis;


import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

	import java.io.IOException;

	public class Servlet2 extends HttpServlet{
	@Override
	public void init()throws ServletException{
		System.out.println("init() Called");
		super.init();
	}
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init(ServletConfig) Called");
		super.init(config);
		}
		@Override
		protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("service2 Called");
		PrintWriter out= resp.getWriter();

		out.println("<h1>Welcome to Servlet2</h1>");
		out.println("<html>");
		out.println("<body>");
		out.println("<a href='Index.jsp'>Back</a>");
		out.println("</body>");
		out.println("</html>");
		RequestDispatcher rd= req.getRequestDispatcher("Servlet3");
		rd.forward(req,  resp);
		//rd.include(req, resp);
	
	}
		
			public void destroy() {
			System.out.println("destroy() Called");
			super.destroy();
			}
			}
	




