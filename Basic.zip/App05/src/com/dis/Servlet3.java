package com.dis;



import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

	import java.io.IOException;

	public class Servlet3 extends HttpServlet{
		protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
			PrintWriter out= resp.getWriter();

			out.println("<h1>Welcome to Servlet3</h1>");
			out.println("<a href='Index.jsp'>Back</a>");
}
}