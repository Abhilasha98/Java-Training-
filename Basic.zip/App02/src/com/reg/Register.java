package com.reg;

public class Register {

}
