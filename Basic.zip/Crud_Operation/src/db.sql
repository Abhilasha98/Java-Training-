create table student_tbl(sid varchar(10) primary key,
sname varchar(30),
email varchar(30));