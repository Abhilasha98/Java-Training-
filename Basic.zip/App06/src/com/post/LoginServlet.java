package com.post;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class LoginServlet extends HttpServlet{
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String un= req.getParameter("uname");
	String pw= req.getParameter("pword");
	//logic to authenticate user
	//code to communicate with db
	String page="index.jsp";
	if(un.equals(pw)) {
		page="home.jsp";
	}
	RequestDispatcher rd= req.getRequestDispatcher(page);
	rd.forward(req, resp);
	}

}
