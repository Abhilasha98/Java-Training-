package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class update {
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
		try {
			String url="jdbc:mysql://localhost:3306/java";
					String username="root";
					String password="abhi";
					 con= DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","abhi");
					if(con!=null) {
						System.out.println("connection established");
					}
					else
					{
					System.out.println("error occured while establishing the connection");
					}
					String tittle;
					String sqlupdate="UPDATE book_tbl SET tittle =? WHERE sno=?";
					try {
					ps=con.prepareStatement(sqlupdate);
					ps.setInt(2, 2);
					ps.setString(1,"CN");
					
					ps.executeUpdate();
					

					


					}catch(SQLException sql) {
					sql.printStackTrace();
					}
					}catch(SQLException sql) {
					sql.printStackTrace();
					}
					}
					}


					
	
	

