package com.db;
	import java.sql.Connection;
	import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
	public class db_setup {
		
		public static void main(String[] args) {
			Connection con = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			}
			catch(ClassNotFoundException cnfe) {
				cnfe.printStackTrace();
			}
			try {
				String url="jdbc:mysql://localhost:3306/java";
						String username="root";
						String password="abhi";
						 con= DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","abhi");
						if(con!=null) {
							System.out.println("connection established");
						}
						else {
							System.out.println("error occured during while establishing the code");
						}
						//ps= con.prepareStatement("select * from book_tbl");
						ps= con.prepareStatement("select * from book_tbl where sno=?");
						ps.setInt(1, 2);
						rs=ps.executeQuery();
						while(rs.next()) {
						System.out.println(rs.getInt(1)+" : "+rs.getString(2)+" : "+rs.getString(3)+" : "+rs.getInt(4));
						}
						} catch (SQLException e) {
						e.printStackTrace();
						}
						finally {
						try {
						if(rs!=null) {
						rs.close();
						}
						if(ps!=null) {
						ps.close();
						}
						if(con!=null) {
						con.close();
						}
						}
						catch (SQLException sqle) {
						sqle.printStackTrace();
						}
						}
						System.out.println("Done");
		
			}
	

}