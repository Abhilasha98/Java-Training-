package com.generic;

//Generic classes

//We use < > to specify Parameter type
class Test<T>
{
 // An object of type T is declared
 T obj;
 Test(T obj) // constructor
 { 
this.obj = obj; 
 }  
 public T getObject() 
 { 
return this.obj; 
}
}

//Driver class to test above
class Main
{
 public static void main (String[] args)
 {
     // instance of Integer type
     Test <Integer> iObj = new Test<Integer>(20);
     System.out.println(iObj.getObject());

     // instance of String type
     Test <String> sObj = new Test<String>("skyblue");
     System.out.println(sObj.getObject());
 }
}