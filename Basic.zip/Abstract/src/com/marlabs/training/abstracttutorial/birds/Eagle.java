package com.marlabs.training.abstracttutorial.birds;

  public class Eagle extends Bird {

	public void eat() {
		System.out.println("grass");
	}
	@Override
	public void fly() {
		System.out.println("flies at high altitude");
	}
	
}
