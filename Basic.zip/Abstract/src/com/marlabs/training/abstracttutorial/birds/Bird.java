package com.marlabs.training.abstracttutorial.birds;

abstract public class Bird {
	abstract public void eat();

	abstract public void fly();

	public void run() {
		System.out.println("fastly");
	}
}