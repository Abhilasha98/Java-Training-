package com.marlabs.training.abstracttutorial;

import com.marlabs.training.abstracttutorial.birds.Bird;
import com.marlabs.training.abstracttutorial.birds.Eagle;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Bird ref = new Eagle();
		ref.eat();

	ref.fly();
		ref.run();
//AEagle e = new AEagle();
//Abird ref;//
// ref = e;
//ref.eat();
		
	}

}
