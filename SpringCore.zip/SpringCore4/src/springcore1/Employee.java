package springcore1;

public class Employee
{
private int empno;
private String name,email,phoneno;
private Project Project;
public Employee(int empno, String name, String email, String phoneno, springcore1.Project project) {
	super();
	this.empno = empno;
	this.name = name;
	this.email = email;
	this.phoneno = phoneno;
	Project = project;
}
@Override
public String toString() {
	return "Employee [empno=" + empno + ", name=" + name + ", email=" + email + ", phoneno=" + phoneno + ", Project="
			+ Project + "]";
}




 



}
