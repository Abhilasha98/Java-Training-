package springcore1;

public class Project 
{
int projectid;
String projectname,projectmanager,location;
public Project(int projectid, String projectname, String projectmanager, String location) {
	super();
	this.projectid = projectid;
	this.projectname = projectname;
	this.projectmanager = projectmanager;
	this.location = location;
}
@Override
public String toString() {
	return "Project [projectid=" + projectid + ", projectname=" + projectname + ", projectmanager=" + projectmanager
			+ ", location=" + location + "]";
}


}
