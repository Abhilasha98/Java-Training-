package springcore1;

public class Bank 
{
int accno,balance;
String bankname;

public Bank(int accno, int balance, String bankname) {
	super();
	this.accno = accno;
	this.balance = balance;
	this.bankname = bankname;
}

@Override
public String toString() {
	return "Bank [accno=" + accno + ", balance=" + balance + ", bankname=" + bankname + "]";
}

}
