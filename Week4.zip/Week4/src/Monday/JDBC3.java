package Monday;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class JDBC3 {
	public static void main(String[] args)throws Exception
	{
		String driverclass="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/sandip";
		String username="root";
		String password="abhi";
		String sql="insert into empmarlabs values(101,'shubham','7766554433',19000)";
		Class.forName(driverclass);
		Connection con=DriverManager.getConnection(url,username,password);
		Statement st=con.createStatement();
		int count=st.executeUpdate(sql);
		System.out.println("inserted row = "+count);
	}
}
