package Monday;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class abhi {
	public static void main(String[] args) throws Exception{
		
		String driverclass="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String username="SYSTEM";
		String password="system";
		String sql="insert into DEPT values(131,'ghshs','Bhr')";
		Class.forName(driverclass);
		Connection con=DriverManager.getConnection(url,username,password);
		Statement st=con.createStatement();
		int count=st.executeUpdate(sql);
		System.out.println("inserted row = "+count);
	}

}
