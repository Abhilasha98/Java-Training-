package Wednesday;
import java.sql.*;
import javax.sql.rowset.JdbcRowSet;
import oracle.jdbc.rowset.OracleJDBCRowSet;
public class JDBCRowset1 
{
public static void main(String[] args)throws Exception
{
	JdbcRowSet rs=new OracleJDBCRowSet();
	rs.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
	rs.setUsername("system");
	rs.setPassword("system");
	rs.setCommand("select * from dept");
	rs.execute();
	boolean first=rs.isBeforeFirst();//true
	boolean last=rs.isAfterLast();//false
	System.out.println("the cursor is at Before First :"+first);
	System.out.println("the cursor is at After Last :"+last);
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3));
	}
	System.out.println("***********************************");
	while(rs.previous())
	{
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3));
	}
	System.out.println("***********************************");
	rs.absolute(2);
	System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3));
	System.out.println("***********************************");
	rs.absolute(1);
	System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3));
	System.out.println("***********************************");
	rs.absolute(4);
	System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3));
	System.out.println("***********************************");
	rs.absolute(-2);
	System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3));
	System.out.println("***********************************");
	rs.first();
	System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3));
	System.out.println("***********************************");
	rs.last();
	System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3));
	}}