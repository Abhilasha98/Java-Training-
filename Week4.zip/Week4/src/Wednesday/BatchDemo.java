package Wednesday;
import java.sql.*;
public class BatchDemo {
	public static void main(String[] args) throws Exception 
	 {
	String driverclass="com.mysql.cj.jdbc.Driver";
	String url="jdbc:mysql://localhost:3306/sandip";
	String username="root";
	String password="abhi";
	Class.forName(driverclass);
	Connection con=DriverManager.getConnection(url,username,password);
	con.setAutoCommit(false);
	Statement st=con.createStatement();
	st.addBatch("insert into student values(11,'affrena','mysore')");
	st.addBatch("insert into student values(5,'rohit','tamilnadu')");
	st.addBatch("insert into student values(6,'mohith','bihar')");
	st.addBatch("delete from student where studid=2");
	st.addBatch("update student set address='bangalore' where studid=2");
	st.executeBatch();
	con.commit();
	System.out.println("Operation Successful");
}
}