package Wednesday;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class TransactionDemo 
{
	public static void main(String[] args) throws Exception
	{
		String driverclass="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/sandip";
		String username="root";
		String password="abhi";
		String sql="insert into student values(2,'sahana','Bangladesh')";
		Class.forName(driverclass);
		Connection con=DriverManager.getConnection(url,username,password);
		con.setAutoCommit(false);
		try
		{
		Statement st=con.createStatement();
		st.execute(sql);
		System.out.println("executed.............");
		con.commit();
		}
		catch(Exception ae)
		{
			con.rollback();
			System.out.println("problem............");
		}
		con.close();
}
}