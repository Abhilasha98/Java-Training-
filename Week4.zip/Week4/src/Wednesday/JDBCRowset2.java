package Wednesday;
import java.sql.*;
import javax.sql.rowset.WebRowSet;
import oracle.jdbc.rowset.OracleWebRowSet;
public class JDBCRowset2 
{
public static void main(String[] args)throws Exception
{
	WebRowSet rs=new OracleWebRowSet();
	rs.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
	rs.setUsername("system");
	rs.setPassword("system");
	rs.setCommand("select * from marlabemp");
	rs.execute();
	boolean first=rs.isBeforeFirst();//true
	boolean last=rs.isAfterLast();//false
	System.out.println("the cursor is at Before First :"+first);
	System.out.println("the cursor is at After Last :"+last);
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+" "+rs.getString(3));
	}
	rs.writeXml(System.out);
	rs.close();
	}
}