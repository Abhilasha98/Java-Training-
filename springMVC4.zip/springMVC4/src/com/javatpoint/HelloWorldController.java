package com.javatpoint;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.*;
@Controller
public class HelloWorldController
{



@RequestMapping("/hello") //input
public ModelAndView helloWorld(HttpServletRequest req,HttpServletResponse res) throws ClassNotFoundException
{
String name=req.getParameter("t1");
String address=req.getParameter("t2");
String email=req.getParameter("t3");
String phoneno=req.getParameter("t4");
String dateofjion=req.getParameter("t5");
String projectname=req.getParameter("t6");
String crud=req.getParameter("t7");
if(crud.equals("insert"))
{
try {
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
PreparedStatement st=con.prepareStatement("insert into maremps123 values(?,?,?,?,?,?)");
st.setString(1, name);
st.setString(2, address);
st.setString(3, email);
st.setString(4, phoneno);
st.setString(5, dateofjion);
st.setString(6, projectname);
st.execute();
}catch(Exception e) {
e.printStackTrace();
}
return new ModelAndView("hellopage","message","row inserted successfully");



}
else if(crud.equals("update"))
{
try {
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
PreparedStatement st2=con.prepareStatement("update maremps123 set address=?,email=?,phoneno=?,doj=?,projname=? where name=?");
st2.setString(1,address);
st2.setString(2, email);
st2.setString(3, phoneno);
st2.setString(4, dateofjion);
st2.setString(5, projectname);
st2.setString(6,name);
st2.execute();
} catch (SQLException e) {



e.printStackTrace();
}
return new ModelAndView("hellopage","message","row updated successfully");
}

/*else if(crud.equals("select")) {
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		Statement st=con.createStatement();
		ResultSet rs = st.executeQuery("select * from maremps123 ");
		while (rs.next()) {
		System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4) +" " + rs.getString(5) +" " + rs.getString(6)  );
		}}
		catch (SQLException e) {
			
			e.printStackTrace();
	}
	return new ModelAndView("hellopage","message","row selected successfully");
	}*/
	
	
else if(crud.equals("delete")) { 
	
	try {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		 PreparedStatement st3=con.prepareStatement("delete from maremps123  where name=?");
			st3.setString(1,name);
			st3.execute();
			System.out.println("row deleted");
	}
	
catch (SQLException e) {
		
		e.printStackTrace();
}
	return new ModelAndView("hellopage","message","row deleted successfully");
}
else
{



return new ModelAndView("show","v1","");


}


}
}