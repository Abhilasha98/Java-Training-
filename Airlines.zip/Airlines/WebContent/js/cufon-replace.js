Cufon.replace('h1, .button_top, h2, .button1, .button2', { fontFamily: 'Myriad Pro It', hover:true });
Cufon.replace('#menu li a, #menu_active', { fontFamily: 'Myriad Pro', hover:true });
Cufon.replace('.text1', { fontFamily: 'Myriad Pro It', hover:true, textShadow:'#2474a2 1px 1px' });

