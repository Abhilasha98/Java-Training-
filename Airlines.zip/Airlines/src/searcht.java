

import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/searcht")
public class searcht extends HttpServlet {

protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {



PrintWriter pw=res.getWriter();
res.setContentType("text/html");
String a=req.getParameter("t1");
String b=req.getParameter("t2");
String c=req.getParameter("t3");
//if(a.equals("admin")&& b.equals("admin"))


	res.sendRedirect("searcht.jsp");
//else
//	res.sendRedirect("admint.html");
}
}


