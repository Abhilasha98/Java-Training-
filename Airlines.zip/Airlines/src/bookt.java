import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/bookt")
public class bookt extends HttpServlet {

protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {



PrintWriter pw=res.getWriter();
res.setContentType("text/html");
String a=req.getParameter("t1");
String b=req.getParameter("t2");
String c=req.getParameter("t3");
String d=req.getParameter("t4");
String e = req.getParameter("t5");
String f = req.getParameter("t6");
String g = req.getParameter("t7");
String h = req.getParameter("t8");
String driverclass="oracle.jdbc.driver.OracleDriver";
String url="jdbc:oracle:thin:@localhost:1521:xe";
String username="system";
String password="system";
//String sql="create table marlabsstud1 (studid number,name varchar2(30),address varchar2(30),password varchar2(30))";
String sql1="insert into book values(?,?,?,?,?,?,?,?)";
try
{
Class.forName(driverclass);
Connection con=DriverManager.getConnection(url,username,password);
//PreparedStatement st=con.prepareStatement(sql);
//st.execute();
PreparedStatement st1=con.prepareStatement(sql1);
st1.setString(1,a);
st1.setString(2,b);
st1.setString(3,c);
st1.setString(4,d);
st1.setString(5, e);
st1.setString(6, f);
st1.setString(7, g);
st1.setString(8, h);
st1.execute();
res.sendRedirect("indext.html");
}
catch(Exception ae)
{
ae.printStackTrace();
}
}

}


