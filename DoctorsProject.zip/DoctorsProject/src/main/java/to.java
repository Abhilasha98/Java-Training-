package="co.vinod.mait.entity">
	
	<!-- class to table mapping -->
	<class name="Person" table="persons">

		<id name="id" column="id" />
		<property name="firstName" column="first_name" />
		<property name="lastName" column="last_name" />
		<property name="phone" column="phone" />
		<property name="email" column="email" />
		

	</class>
	
	
</hibernate-mapping>
