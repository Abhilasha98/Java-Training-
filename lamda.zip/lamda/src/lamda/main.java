
package lamda;
//Method reference to a static method of a class
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.BiFunction;
public class main {

	public static void main(String[] args) {
List<String> l1 = new ArrayList<String>();
l1.add("abhi");
l1.add("niri");
l1.add("madhu");
l1.add("mithri");
int count = 0;

//l1.forEach(name->System.out.println(name));
for(String str : l1) {
	if(str.length()<6) 
		count++;
	
}
//long count = l1.stream().filter(f1->f1.length()<6).count();
System.out.println("There are "+count+" strings with length less than 6");



	}
	
	}
	