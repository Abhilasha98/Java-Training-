package lamda;

public interface square {
void display(String say);
}
