package lamda;

public class Mul {
public Mul(String say) {
	System.out.print(say);
}
}
