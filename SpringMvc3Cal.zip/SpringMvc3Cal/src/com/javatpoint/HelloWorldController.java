package com.javatpoint;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.*;
@Controller
public class HelloWorldController 
{

	@RequestMapping("/hello") //input 
	public ModelAndView helloWorld(HttpServletRequest req,HttpServletResponse res)
	{   
		int n1=Integer.parseInt(req.getParameter("t1"));
		int n2=Integer.parseInt(req.getParameter("t2"));
		String cal=req.getParameter("t3");
		if(cal.equals("Add"))
		{
			int n3=n1+n2;
		
		return new ModelAndView("hellopage","message",n3);
		}
		else if(cal.equals("Sub"))
		{
		int n3=n1-n2;
		//String num4=Integer.toString(num3);
		return new ModelAndView("hellopage","message",n3);

		}
		else if(cal.equals("Mul"))
		{
		int n3=n1*n2;
		//String num4=Integer.toString(num3);
		return new ModelAndView("hellopage","message",n3);
		}
		else
		{
		int n3=n1/n2;
		//String num4=Integer.toString(num3);
		return new ModelAndView("hellopage","message",n3);
		}
	
	}
}
	

