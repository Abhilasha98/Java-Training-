package DAO;
import org.hibernate.*;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import DTO.DTODemo;
public class DaoDemo
{
public void saveData(DTODemo d)
{
	Configuration cfg=new Configuration();
	cfg.configure();
	SessionFactory factory=cfg.buildSessionFactory();
	Session ss=factory.openSession();
	Transaction tx=ss.beginTransaction();
	ss.save(d);
	tx.commit();
}
}
