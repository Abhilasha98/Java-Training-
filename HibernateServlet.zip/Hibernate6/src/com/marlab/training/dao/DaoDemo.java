package com.marlab.training.dao;
import org.hibernate.*;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.marlab.training.entity.EntityDemo;




public class DaoDemo
{
public void saveData(EntityDemo d)
{
Configuration cfg=new Configuration();
cfg.configure();
SessionFactory factory=cfg.buildSessionFactory();
Session ss=factory.openSession();
Transaction tx=ss.beginTransaction();
ss.save(d);
tx.commit();
}
}