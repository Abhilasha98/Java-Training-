import java.io.*;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/SecondPage")
public class SecondPage extends HttpServlet 
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)
	{
		try
		{
			PrintWriter pw=res.getWriter();
			res.setContentType("text/html");
			String a=req.getParameter("t1");
			String b=req.getParameter("t2");
			String c=req.getParameter("t3");
			String d=req.getParameter("t4");
			pw.println("The name is :"+a);
			pw.println("The address is :"+b);
			pw.println("The phone no is :"+c);
			pw.println("The email is :"+d);
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
	}
}