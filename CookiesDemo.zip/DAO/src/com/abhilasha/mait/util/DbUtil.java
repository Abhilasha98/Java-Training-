package com.abhilasha.mait.util;
import java.sql.*;

import com.abhilasha.mait.dao.DaoException;
public class DbUtil 
{

public static Connection getConnection() throws DaoException, Exception
{
	String driver,url,user,password;
	driver="oracle.jdbc.driver.OracleDriver";
	url="jdbc:oracle:thin:@localhost:1521:xe";
	user="system";
	password="system";
	Class.forName(driver);
	return DriverManager.getConnection(url,user,password);
}
}
