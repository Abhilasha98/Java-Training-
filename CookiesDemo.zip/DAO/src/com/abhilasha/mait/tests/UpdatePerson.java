package com.abhilasha.mait.tests;

import com.abhilasha.mait.dao.DaoException;
import com.abhilasha.mait.dao.PersonDao;
import com.abhilasha.mait.dao.impl.JdbcPersonDao;
import com.abhilasha.mait.entity.Person;

public class UpdatePerson {
	public static void main(String[] args) throws DaoException
	
	{
		PersonDao dao=new JdbcPersonDao();
		int id=102;
		Person p=dao.getPerson(id);
		if(p==null)
		{
		System.out.println("Person data not there");
		}
		else
		{
		Person person =new Person(102,"kajal","shetty","9036580430","afreen@gmail.com");
		//PersonDao dao=new JdbcpersonDao();
		dao.updatePerson(person);
		System.out.println("Person data updated");
	
		}
}}
