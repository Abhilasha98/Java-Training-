package com.abhilasha.mait.tests;

import java.util.List;

import com.abhilasha.mait.dao.DaoException;
import com.abhilasha.mait.dao.PersonDao;
import com.abhilasha.mait.dao.impl.JdbcPersonDao;
import com.abhilasha.mait.entity.Person;

public class GetAllPersons 
{
public static void main(String[] args) throws DaoException
{
PersonDao dao=new JdbcPersonDao();
List <Person>list=dao.getAllPersons();
for(Person p : list)
{
System.out.println(p.getId()+" "+p.getFirstName()+" "+p.getLastName());
}
}
}
