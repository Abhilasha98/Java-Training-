package com.abhilasha.mait.tests;

import com.abhilasha.mait.dao.DaoException;
import com.abhilasha.mait.dao.PersonDao;
import com.abhilasha.mait.dao.impl.JdbcPersonDao;
import com.abhilasha.mait.entity.Person;

public class AddPerson 
{
public static void main(String[] args) throws DaoException
{
Person person =new Person(102,"amrutha","Shetty","9488776855","am@gmail.com");
PersonDao dao=new JdbcPersonDao();
dao.addPerson(person);
System.out.println("Person data added");
}
}
