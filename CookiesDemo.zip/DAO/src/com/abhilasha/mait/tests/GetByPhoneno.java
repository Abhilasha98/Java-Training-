package com.abhilasha.mait.tests;

import com.abhilasha.mait.dao.DaoException;
import com.abhilasha.mait.dao.PersonDao;
import com.abhilasha.mait.dao.impl.JdbcPersonDao;
import com.abhilasha.mait.entity.Person;

public class GetByPhoneno {
	public static void main(String[] args) throws DaoException {
	PersonDao dao=new JdbcPersonDao();
	String phone="9036580430";
	Person p=dao.getPersonByPhone(phone);
	if(p==null)
	{
	System.out.println("Person data not there");
	}
	else
	{
	System.out.println(p);
	}
	
	}
}

