package com.abhilasha.mait.tests;

import com.abhilasha.mait.dao.DaoException;
import com.abhilasha.mait.dao.PersonDao;
import com.abhilasha.mait.dao.impl.JdbcPersonDao;
import com.abhilasha.mait.entity.Person;

public class GetOnePerson 
{
public static void main(String[] args) throws DaoException
{
PersonDao dao=new JdbcPersonDao();
int id=102;
Person p=dao.getPerson(id);
if(p==null)
System.out.println("Person data not there");
else
	System.out.println(p);
}
}
