import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Session1")
public class Session1 extends HttpServlet 
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		HttpSession ses=req.getSession(true);
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		ses.setAttribute("ob",a);
		ses.setAttribute("ob1",b);
		ses.setAttribute("ob2",c);
		ses.setAttribute("ob3",d);
		pw.println("<html>");
		pw.println("<body bgcolor=cyan>");
		pw.println("<form action=Session2 method=get>");
		pw.println("Enter the product1 name :");
		pw.println("<input type=text name=t5  size=20 required>");
		pw.println("Enter the product1 price :");
		pw.println("<input type=text name=t6  size=20 required>");
		pw.println("<input type=submit value=Submit>");
		pw.println("</body>");
		pw.println("</form></html>");
		}
	}
