import java.io.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Session2")
public class Session2 extends HttpServlet 
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		HttpSession ses=req.getSession(false);
		String e=req.getParameter("t5");
		String f=req.getParameter("t6");
		ses.setAttribute("ob4",e);//session object
		ses.setAttribute("ob5",f);
		pw.println("<html>");
		pw.println("<body bgcolor=cyan>");
		pw.println("<form action=Session3 method=get>");
		pw.println("Enter the product2 name :");
		pw.println("<input type=text name=t7  size=20 required>");
		pw.println("Enter the product2 price :");
		pw.println("<input type=text name=t8  size=20 required>");
		pw.println("<input type=submit value=Submit>");
		pw.println("</body>");
		pw.println("</form></html>");
		}
	}