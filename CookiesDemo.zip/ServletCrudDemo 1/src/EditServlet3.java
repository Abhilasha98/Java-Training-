import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/EditServlet3")
public class EditServlet3 extends HttpServlet {
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		String sid=req.getParameter("id");
		int id=Integer.parseInt(sid);
		String name=req.getParameter("name");
		String password=req.getParameter("password");
		String email=req.getParameter("email");
		String country=req.getParameter("country");
		String phoneno=req.getParameter("phoneno");
		String projectname = req.getParameter("projectname");
		
		Emp1 e=new Emp1();
		e.setId(id);
		e.setPassword(password);
		e.setName(name);
		e.setEmail(email);
		e.setCountry(country);
		e.setPhoneno(phoneno);
		e.setProjectname(projectname);
		int status=EmpDao1.update(e);
		if(status>0)
		{
			res.sendRedirect("ViewServlet1");
		}
		else
		{
			pw.println("Sorry not updated");
		}
		
	}
}
