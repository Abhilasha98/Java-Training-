import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/DeleteServlet1")
public class DeleteServlet1 extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String sid=req.getParameter("id");
		int id=Integer.parseInt(sid);
		EmpDao1.delete(id);
		res.sendRedirect("ViewServlet1");
	}
}
